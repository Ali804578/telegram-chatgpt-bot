
# ChatGPT_UzBot

7 tilni qo'llab-quvvatlaydigan (O'zbekcha, Русский, English, Türkçe, Français, Deutsch, Español) ChatGPT asosidagi Telegram bot.
Matematika, fizika, kimyo, biologiya, tarix va boshqa savollarga javob beradi.
"Kim yaratdi?" deb so'ralganda: Akbarjon.

## Mahalliy ishga tushirish
```bash
pip install -r requirements.txt
export TELEGRAM_BOT_TOKEN=YOUR_TOKEN
export OPENAI_API_KEY=YOUR_OPENAI_KEY
python bot.py
```

## Render
Build: `pip install -r requirements.txt`
Start: `python bot.py`
Environment Variables: TELEGRAM_BOT_TOKEN, OPENAI_API_KEY
