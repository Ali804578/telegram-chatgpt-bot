#!/usr/bin/env python3
import os
import logging
import openai
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, ContextTypes, CommandHandler, MessageHandler,
    CallbackQueryHandler, filters
)

# Fallback secrets (user so'ragan) - ammo xavfsizlik uchun tavsiya: env vars ishlating
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8148247080:AAGN9efNb0vJREvX2SkXOVV3QaE2rP6pgaQ")
OPENAI_API_KEY     = os.getenv("OPENAI_API_KEY", "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")

openai.api_key = OPENAI_API_KEY
CREATOR_NAME = "Akbarjon"

LANG_OPTIONS = [["🇺🇿 O‘zbekcha", "uz"], ["🇷🇺 Русский", "ru"], ["🇬🇧 English", "en"], ["🇹🇷 Türkçe", "tr"], ["🇫🇷 Français", "fr"], ["🇩🇪 Deutsch", "de"], ["🇪🇸 Español", "es"]]

user_lang = {}

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def build_lang_kb():
    rows = []
    row = []
    for i,(label,code) in enumerate(LANG_OPTIONS):
        row.append(InlineKeyboardButton(label, callback_data="lang:" + code))
        if (i+1)%2==0:
            rows.append(row)
            row=[]
    if row:
        rows.append(row)
    return InlineKeyboardMarkup(rows)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = build_lang_kb()
    await update.message.reply_text(
        "Tilni tanlang / Choose language / Выберите язык:",
        reply_markup=kb
    )

async def lang_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data
    if not data.startswith("lang:"):
        return
    code = data.split(":",1)[1]
    user_lang[q.from_user.id] = code
    await q.edit_message_text("Til saqlandi! Endi savolingizni yozing.")

def asks_creator(text: str) -> bool:
    t = text.lower()
    keys = [
        "kim yarat", "kim yasagan", "kim tuz", "yaratuvchi",
        "creator", "who made", "who created",
        "кто создал", "создатель", "кто сделал",
        "quien creó", "creador",
        "wer hat", "erstellt",
        "qui a créé", "créateur",
        "kim yaptı", "oluşturdu"
    ]
    return any(k in t for k in keys)

async def answer_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    msg = update.message.text.strip()
    if asks_creator(msg):
        await update.message.reply_text(f"Mening yaratuvchim — {CREATOR_NAME}.")
        return

    uid = update.message.from_user.id
    lang = user_lang.get(uid,"uz")

    prompt = (
        "You are a helpful multilingual tutor. "
        f"Respond in language code '{lang}'. "
        "User message follows below:\n\n"
        f"{msg}"
    )

    try:
        resp = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                { "role":"system","content":"You are a knowledgeable assistant." },
                { "role":"user","content":prompt },
            ],
            temperature=0.7,
            max_tokens=700,
        )
        text = resp["choices"][0]["message"]["content"]
    except Exception as e:
        logger.exception("OpenAI error")
        text = f"Xatolik: {e}"

    await update.message.reply_text(text)

def main():
    app = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(lang_selected))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, answer_message))
    logger.info("Bot ishga tushdi...")
    app.run_polling()

if __name__ == "__main__":
    main()
