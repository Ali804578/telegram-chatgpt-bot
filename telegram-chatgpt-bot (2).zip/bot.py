
import logging
import openai
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

# Tokenlar
TELEGRAM_BOT_TOKEN = "8148247080:AAGN9efNb0vJREvX2SkXOVV3QaE2rP6pgaQ"
OPENAI_API_KEY = "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"

# OpenAI sozlamalari
openai.api_key = OPENAI_API_KEY

# Log sozlamalari
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

# Xabar yuborishda ishlatiladigan funksiya
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_message = update.message.text

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                { "role": "user", "content": user_message }
            ]
        )
        await update.message.reply_text(response['choices'][0]['message']['content'])
    except Exception as e:
        await update.message.reply_text("Xatolik yuz berdi: " + str(e))

# Botni ishga tushirish funksiyasi
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Salom! Men ChatGPT Telegram botiman. Menga savol bering!")

def main():
    application = ApplicationBuilder().token(TELEGRAM_BOT_TOKEN).build()

    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    application.run_polling()

if __name__ == '__main__':
    main()
